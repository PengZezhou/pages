# 静态网页模板开发脚手架

-   打开文件目录 npm i 下载依赖

目录说明

app：工程主目录  
app/html：静态 html 文件夹  
app/images：图片资源文件夹  
app/js：js 文件夹  
app/less：样式文件夹  
app/web：编译过后的 html 文件夹  
app/css： 编译过后的 css 文件夹
