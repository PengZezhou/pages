const { series, parallel, src, dest, watch } = require('gulp');
var connect = require("gulp-connect");
var fileinclude = require("gulp-file-include"); //html模板合并include
var less = require("gulp-less");
var postcss = require("gulp-postcss");
var autoprefixer = require("autoprefixer");
var csscomb = require("gulp-csscomb");
var shortColor = require("postcss-short-color");
var cleanCSS = require("gulp-clean-css");
var rename = require("gulp-rename"); //重命名

function html() {
    return src(["./app/html/*.html"])
        .pipe(
            fileinclude({
                prefix: "@",
                basepath: "./app/html/"
            })
        )
        .pipe(dest("app/web/"))
        .pipe(connect.reload());
}

/*
 * 编译less样式文件
 */
function css() {
    return src(["./app/html/*.less"])
        .pipe(less())
        .pipe(
            postcss([
                shortColor,
                autoprefixer({
                    cascade: false
                })
            ])
        )
        .pipe(csscomb())
        .pipe(dest("app/css/"))
        .pipe(
            cleanCSS({
                compatibility: "ie8"
            })
        )
        .pipe(
            rename({
                suffix: ".min"
            })
        )
        .pipe(dest("app/css/"))
        .pipe(connect.reload());
}

function webserver() {
    connect.server({
        host:"0.0.0.0",
        port: 3311,
        livereload: true
    });
}

function watchTask() {
    // 注意这里不需要使用return
    watch(["app/html/*.html"], parallel(html));
    watch(["app/html/*.less"], parallel(css));
}

exports.default = parallel(webserver, watchTask)